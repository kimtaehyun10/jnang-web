create table {BLOCKTABLE}
( 
subid varchar(20) not null,
dstaddr varchar(20) not null, 
msg_type char(1), 
reg_time datetime year to second default current year to second not null, 
memo varchar(30), 
primary key (subid,dstaddr,msg_type) 
);

