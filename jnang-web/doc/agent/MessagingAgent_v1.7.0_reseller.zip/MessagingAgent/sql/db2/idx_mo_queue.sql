create index idx_mo_queue1 on {TABLENAME}(daaddr);
