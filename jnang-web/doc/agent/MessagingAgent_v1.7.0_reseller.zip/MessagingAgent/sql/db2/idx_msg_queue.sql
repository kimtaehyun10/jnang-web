create index idx_{SENDTABLE}_sel on {SENDTABLE}(stat,request_time,msg_type);

