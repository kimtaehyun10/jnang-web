create table {BLOCKTABLE}
( 
subid varchar2(20) not null,
dstaddr varchar2(20) not null, 
msg_type char(1) null, 
reg_time date null, 
memo varchar2(30), 
primary key (subid,dstaddr,msg_type) 
);

