create table {SCHM}.{BLOCKTABLE}
( 
subid varchar(20) not null,
dstaddr varchar(20) not null, 
msg_type char(1) null, 
reg_time date null, 
memo varchar(30), 
constraint pk_{BLOCKTABLE} primary key (subid,dstaddr,msg_type)
);


